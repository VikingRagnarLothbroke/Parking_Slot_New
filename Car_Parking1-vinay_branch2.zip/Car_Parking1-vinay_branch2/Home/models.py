from django.db import models

# Create your models here.
class User_information(models.Model):
    pass